﻿using Azure.Storage.Blobs;
using Ruralreformers.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Ruralreformers.Helper
{
    public class CloudIntegrationHelper
    {
        private const string ConnectionString = "DefaultEndpointsProtocol=https;AccountName=ruralreformersstorage;AccountKey=K/eJjMW8ZC0FPxKL1B9SiB0OwCxv4jW3C2Ln+gSCeDkciMEkLM35YHFH57Bhcj2b1s+2lzUYx696wXOKQZRwkw==;EndpointSuffix=core.windows.net";

        public CloudIntegrationHelper()
        {

        }

        public async Task<bool> SaveUserInformation(Registeration registeration)
        {
            try
            {
                // Create a BlobServiceClient object which will be used to create a container client
                BlobServiceClient blobServiceClient = new BlobServiceClient(ConnectionString);

                //Create a unique name for the container
                string containerName = registeration.Name + Guid.NewGuid().ToString();

                // Create the container and return a container client object
                BlobContainerClient containerClient = await blobServiceClient.CreateBlobContainerAsync(containerName);

                // Create a local file in the ./data/ directory for uploading and downloading
                string localPath = "./data/";
                string fileName = registeration.Name + Guid.NewGuid().ToString() + ".txt";
                string localFilePath = Path.Combine(localPath, fileName);

                // Write text to the file
                await File.WriteAllTextAsync(localFilePath, Newtonsoft.Json.JsonConvert.SerializeObject(registeration));

                // Get a reference to a blob
                BlobClient blobClient = containerClient.GetBlobClient(fileName);

                // Upload data from the local file
                 await blobClient.UploadAsync(localFilePath, true);
            }
            catch(Exception ex)
            {
                return false;
            }

            return true;
        }     
    }
}
